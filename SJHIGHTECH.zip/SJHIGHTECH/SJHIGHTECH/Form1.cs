﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace SJHIGHTECH
{
    public partial class Form1 : Form
    {
       public string[] name = new string[30];
        string[] boxBarcode = new string[30];
        public string[] itemBarcode = new string[30];
        int nameCol = 1;
        int boxCol = 2;
        int itemCol = 3;
        int orderCol = 4;
        int dateCol = 5;
        public int current;
        public int count = 0;
        public string order = "";
        Excel.Application excel;
        Excel.Workbook workbook;
        Excel.Worksheet worksheet1;
        Excel.Worksheet worksheet2;

        [STAThread]

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        private LowLevelKeyboardProc _proc;
        private static IntPtr _hookID = IntPtr.Zero;

        public Form1()
        {
            _proc = HookCallback;
            _hookID = SetHook(_proc);
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;

            excel = new Excel.Application();
            workbook = excel.Workbooks.Open("C:\\SJ\\DATA.xlsx");
            worksheet1 = (Excel.Worksheet)workbook.Sheets[1];
            worksheet2 = (Excel.Worksheet)workbook.Sheets[2];

            int lastRow1 = worksheet2.Cells[worksheet2.Cells.Rows.Count, 1].End(XlDirection.xlUp).Row;
            for (int i = 0; i < lastRow1 - 1; i++)
            {
                name[i] = worksheet2.Cells[i + 2, nameCol].Value.ToString();
                boxBarcode[i] = worksheet2.Cells[i + 2, boxCol].Value.ToString();
                itemBarcode[i] = worksheet2.Cells[i + 2, itemCol].Value.ToString();
            }

            textBox1.Focus();
            textBox2.Enabled = false;
        }


        private IntPtr SetHook(LowLevelKeyboardProc proc)
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle(curModule.ModuleName), 0);
            }
        }

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {

            int vkCode = Marshal.ReadInt32(lParam);
            if (nCode >= 0 && wParam == (IntPtr)WM_KEYDOWN && vkCode == 13)
            {
                button1.Focus();
             
            }

            return CallNextHookEx(_hookID, nCode, wParam, lParam);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            workbook.Close();
            excel.Quit();
            Marshal.ReleaseComObject(workbook);
            Marshal.ReleaseComObject(excel);
            UnhookWindowsHookEx(_hookID);
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            bool check = false;
            if(count == 0)
            {
                MessageBox.Show("주문번호를 입력하세요");
                textBox1.Text = "";
                textBox1.Focus();
                return;
            }
            if (textBox1.Enabled == true)
            {

                if (itemBarcode[current] == textBox1.Text)
                {
                    check = true;
                }
                if (check)
                {
                    textBox1.Enabled = false;
                    this.Invoke((MethodInvoker)delegate
                    {
                        showLabel.Text = "박스를 찍어주세요";
                        textBox2.Enabled = true;
                        textBox2.Focus();
                    });
                    check = false;
                }
                else
                {

                    textBox1.Enabled = false;
                    this.Invoke((MethodInvoker)async delegate
                    {
                        showLabel.Text = "         FAIL";
                        showLabel.ForeColor = System.Drawing.Color.Red;
                        MessageBox.Show("제품을 확인해주세요");
                        await Task.Delay(1000);
                        textBox1.Enabled = true;
                        showLabel.Text = "제품을 찍어주세요";
                        showLabel.ForeColor = System.Drawing.Color.Black;
                        textBox1.Text = "";
                        textBox1.Focus();
                    });

                }
            }
            else
            {

                if (boxBarcode[current] == textBox2.Text)
                {
                    check = true;
                }

                if (check == true)
                {
                    this.Invoke((MethodInvoker)async delegate
                    {
                        textBox2.Enabled = false;
                        showLabel.Text = "         PASS";
                        showLabel.ForeColor = System.Drawing.Color.Blue;
                        await Task.Delay(1000);
                        textBox1.Enabled = true;                   
                        showLabel.Text = "제품을 찍어주세요";
                        showLabel.ForeColor = System.Drawing.Color.Black;
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox1.Focus();

                        count--;
                        label5.Text = count.ToString(); 
                        if(count ==0)
                        {
                            label3.Text = "주문번호를 입력하세요";
                            label3.ForeColor = System.Drawing.Color.Black;
                        }
                        
                        DateTime dateTime = DateTime.Now;
                        int lastRow1 = worksheet1.Cells[worksheet2.Cells.Rows.Count, 1].End(XlDirection.xlUp).Row;
                        worksheet1.Cells[lastRow1+1, nameCol].Value = name[current];
                        worksheet1.Cells[lastRow1+1, boxCol].Value = boxBarcode[current];  
                        worksheet1.Cells[lastRow1+ 1, itemCol].Value = itemBarcode[current];
                        worksheet1.Cells[lastRow1 + 1, orderCol].Value = order;
                        worksheet1.Cells[lastRow1 + 1, dateCol].Value = dateTime.ToString();
                        workbook.Save();


                    });
                }
                else
                {
                    textBox2.Enabled = false;
                    this.Invoke((MethodInvoker)async delegate
                    {
                        showLabel.Text = "         FAIL";
                        showLabel.ForeColor = System.Drawing.Color.Red;
                        MessageBox.Show("박스를 확인해주세요");
                        await Task.Delay(1000);
                        textBox1.Enabled = true;
                        showLabel.Text = "제품을 찍어주세요";
                        showLabel.ForeColor = System.Drawing.Color.Black;
                        textBox1.Text = "";
                        textBox1.Focus();
                    });
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(this);
            form2.ShowDialog();
            textBox1.Focus();
        }

    }
}