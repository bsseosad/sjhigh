﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SJHIGHTECH
{
    public partial class Form2 : Form
    {
        Form1 form1;
        public Form2(Form1 form1)
        {
            InitializeComponent();
      
            this.form1 = form1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number;
            if (!int.TryParse(textBox3.Text, out number)||number<=0)
            {
                MessageBox.Show("수량에 0 이상의 숫자를 입력하세요");
                textBox3.Text = "";
                return;
            }

            for(int i = 0; i <form1.itemBarcode.Length;i++)
            {
                if(textBox2.Text == form1.itemBarcode[i])
                {                
                    form1.current = i;
                    form1.count = number;
                    form1.order = textBox1.Text;
                    form1.label3.Text = form1.name[i];
                    form1.label3.ForeColor = Color.Orange;
                    form1.label5.Text = number.ToString();
                    form1.textBox1.Focus();
                    this.Close();
                    return;
                }
            }


        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox3.Focus();
        }
    }
}
